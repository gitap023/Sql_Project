<h1 align="center">Hi 👋, I'm Priyang Bhatt</h1>
<h3 align="center">Educator By Day. Data Scientist By Night</h3>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=priyang-bhatt&label=Profile%20views&color=0e75b6&style=flat" alt="priyang-bhatt" /> </p>


<h3 >Above Folder "DS" Contains All The Datasets that I'm using in my Youtube Projects </h3>

- 👨‍💻 All of my projects are available at [https://www.youtube.com/c/priyangbhatt](https://www.youtube.com/c/priyangbhatt)

- 📫 How to reach me **bhattpriyang@gmail.com**

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://developer.android.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/> </a> <a href="https://www.arduino.cc/" target="_blank" rel="noreferrer"> <img src="https://cdn.worldvectorlogo.com/logos/arduino-1.svg" alt="arduino" width="40" height="40"/> </a> <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> <a href="https://flask.palletsprojects.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/pocoo_flask/pocoo_flask-icon.svg" alt="flask" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://scikit-learn.org/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Scikit_learn_logo_small.svg" alt="scikit_learn" width="40" height="40"/> </a> </p>

<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=priyang-bhatt&show_icons=true&locale=en&layout=compact" alt="priyang-bhatt" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=priyang-bhatt&show_icons=true&locale=en" alt="priyang-bhatt" /></p>

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=priyang-bhatt&" alt="priyang-bhatt" /></p>
